<!DOCTYPE html>
<html>
<style>
table,th,td {
  border : 3px solid black;
  border-collapse: collapse;
}
th,td {
  padding: 5px;
}
</style>
<body>

<h1><p style="color:green"> Divisions & Districts of Bangladesh </p></h1>

<form name="form1" action=""> 
<select name="country" id="country" >
<option value="">Select a Division:</option>
    <option value="Dhaka">Dhaka</option>
    <option value="Chittagong">Chittagong</option>
    <option value="Khulna">Khulna</option>
	<option value="Barishal">Barishal</option>
    <option value="Sylhet">Sylhet</option>
    <option value="Rajshahi">Rajshahi</option>
	<option value="Rangpur">Rangpur</option>
    <option value="Mymensingh">Mymensingh</option>
</select>
</form>
<br>
<div id="txtHint"><p style="color:blue"> showing the list...</p></div>



<script>
function showCustomer(str,pageno) {
  var xhttp;    
  if (str == "") {
    document.getElementById("txtHint").innerHTML = "";
    return;
  }
  xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      document.getElementById("txtHint").innerHTML = this.responseText;
    }
  };
  xhttp.open("GET", "form2.php?q="+str+"&pageno="+pageno, true);
  xhttp.send();


}
var count=1;
var c =document.getElementById("country");
c.onchange=function(){
  showCustomer(c.value,count);
}


function myfunction( v ){
  showCustomer(c.value,v);
 
}




  
</script>





</body>
</html>